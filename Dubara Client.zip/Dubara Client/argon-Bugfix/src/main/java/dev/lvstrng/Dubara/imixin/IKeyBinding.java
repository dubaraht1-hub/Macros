package dev.lvstrng.Dubara.imixin;

public interface IKeyBinding {
	boolean isActuallyPressed();

	void resetPressed();
}
