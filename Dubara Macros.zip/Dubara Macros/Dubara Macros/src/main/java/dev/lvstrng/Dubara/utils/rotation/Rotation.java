package dev.lvstrng.Dubara.utils.rotation;


public record Rotation(double yaw, double pitch) {
}
