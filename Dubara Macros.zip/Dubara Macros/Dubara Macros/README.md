# ‼️‼️‼️**PLEASE READ THIS AND THE LICENSE** ‼️‼️‼️

***PLEASE READ THE LICENSE BEFORE DOING ANYTHING WITH THE SOURCE CODE OF THE CLIENT.***.

I am writing this because I see a lot of people copying my work and selling it without giving me credit or informing me/asking me for permission. Well, you are **NOT** allowed to rename this client. You are **NOT** allowed to refer to this client or anything you copy from it as if it's owned by you.

***PLEASE READ THE LICENSE BEFORE DOING ANYTHING WITH THE SOURCE CODE OF THE CLIENT.***.

You are allowed to modify the code of this client and publish your version of this client **either as open-source or closed-source, but not sold.** Please respect me, my project and yourself.

# Argon Minecraft Ghost Client

## Why?

Originally a paid client, but since the new owner dumped me from the dev team of MY OWN CLIENT (yes, the client I STARTED and made about 85% of the client (but only got 30% of all the money made what the scam)) and demoted me, I decided to release the source code. I will try to update this as much as possible. I have updated the client to 1.21 but the damage utils are broken because mojang and fabric decide to change irrelevant stuff every update. The client cost 15 pounds for normal and 25 for beta, which ablue never ever finished and it turns out you just paid 10 bucks for the same shit. Ablue also ignores my DMs. When she does it's always the nword, insulting me or just a question mark. Ablue has also deleted a lot of old messages from my DMs and from other's too, you maybe might notice if you go through her DMs.

This version of the client has auth removed COMPLETELY, so don't worry, the client won't crash on launch because of ablue's scary code. This version of the client also does NOT hide strings from memory, since ablue never really gave me full access over my own client (that being: giving me the string transformer so i can hide strings in memory). The code for hiding strings is in `EncryptedString`. If you do create one and want to support the project, please DM me on discord (I will not be buying the transformer): ```lvstrng```

NOTE: Some of the stuff here is pasted by ablue lmaooo (Not damage utils, I was lazy to make damage utils for 1.21 so i just pasted from meteor client)

## How to build

- Launch the project in IntelliJ
- Make a new configuration and make it do `build`
- Find jar in project's `build/libs` (name should be argon-b1.1.jar unless you change it) 
![image](https://github.com/user-attachments/assets/b2e8853e-2916-4219-9443-85ff7549d418)
